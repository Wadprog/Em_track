/****
 *
 *  List to the new tokens cretion then if the creator wallet matches one of the new wallets in the database we add the token to the database.
 * Lat Modified: 2024-11-30\\
 * Last modification, changed the  post url from new_token to tokens
 */
//*** */

import axios from 'axios'
import WebSocket from 'ws'
import { subMinutes }  from "date-fns";

const ws = new WebSocket('wss://pumpportal.fun/api/data')

ws.on('open', function open() {
  console.log('Connected to Pumpfun WebSocket')
  // Subscribing to token creation events
  let payload = {
    method: 'subscribeNewToken',
  }
  ws.send(JSON.stringify(payload))
})

ws.on('message', async (data) => {
  console.log('Checking for new tokens')
  const parsedData = JSON.parse(data)
  axios
    .get(
      'http://em_api:3000/wallets?destination=' + parsedData.traderPublicKey
    )
    .then((res) => {
      if (res.data.length) {
        axios.post('http://em_api:3000/tokens', {
          mint: parsedData.mint,
          walletId: res?.data[0]?.id,
          timestamp: Date.now(),
          updated_at:  subMinutes(new Date(), 5),
          origin: 'new_token',
        })
      }
    })
})
